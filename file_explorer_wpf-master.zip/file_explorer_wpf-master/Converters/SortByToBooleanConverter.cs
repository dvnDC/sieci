﻿using System;
using System.Globalization;
using System.Windows.Data;
using WpfApp1.Enums;

namespace WpfApp1.Converters
{
    public class SortByToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value != null && value.ToString().Equals(parameter.ToString());
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value != null && (bool)value ? Enum.Parse(typeof(SortBy), parameter.ToString()) : Binding.DoNothing;
        }
    }
}