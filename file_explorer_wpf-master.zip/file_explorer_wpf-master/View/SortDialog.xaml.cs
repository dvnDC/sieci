﻿using System;
using System.Windows;
using WpfApp1.Enums;
using WpfApp1.Model;

namespace WpfApp1.View
{
    public partial class SortDialog : Window
    {
        private readonly FileExplorer _fileExplorer;

        public SortDialog(FileExplorer fileExplorer)
        {
            InitializeComponent();
            _fileExplorer = fileExplorer ?? throw new ArgumentNullException(nameof(fileExplorer));
            DataContext = _fileExplorer.SortOptions;
        }

        private void SortButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Upewnij się, że SortOptions są zaktualizowane
                _fileExplorer.SortOptions.SortBy = GetSelectedSortType();
                _fileExplorer.SortOptions.Direction = GetSelectedSortOrder();
                _fileExplorer.SortOptions.KeepFoldersOnTop = SeparateFoldersCheckBox.IsChecked ?? false;

                // Wykonaj komendę sortowania
                _fileExplorer.SortRootFolderCommand.Execute(null);

                this.DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private SortBy GetSelectedSortType()
        {
            if (AlphabeticallyRadioButton.IsChecked == true) return SortBy.Alphabetically;
            if (ByExtensionRadioButton.IsChecked == true) return SortBy.ByExtension;
            if (BySizeRadioButton.IsChecked == true) return SortBy.BySize;
            if (ByDateModifiedRadioButton.IsChecked == true) return SortBy.ByDateModified;
            return SortBy.Alphabetically; // Domyślnie sortuj alfabetycznie
        }

        private Direction GetSelectedSortOrder()
        {
            return AscendingRadioButton.IsChecked == true ? Direction.Ascending : Direction.Descending;
        }
    }
}