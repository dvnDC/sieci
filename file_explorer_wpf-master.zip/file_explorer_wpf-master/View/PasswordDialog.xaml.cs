﻿using System.Security;
using System.Windows;

namespace WpfApp1.View
{
    public partial class PasswordDialog : Window
    {
        public SecureString Password { get; private set; }
        public string Message { get; set; }

        public PasswordDialog()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            Password = PasswordBox.SecurePassword;
            DialogResult = true;
            Close();
        }
    }
}
