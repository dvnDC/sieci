﻿using System.Globalization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp1.Model;
using WpfApp1.Enums;
using Application = System.Windows.Application;
using System.Diagnostics;

namespace WpfApp1.View
{
    public partial class MainWindow : Window
    {
        private readonly FileExplorer _fileExplorer = new FileExplorer();

        public MainWindow()
        {
            InitializeComponent();
            _fileExplorer = new FileExplorer();
            DataContext = _fileExplorer;
            Debug.WriteLine("MainWindow initialized.");
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("MainWindow loaded.");
            await _fileExplorer.OpenRootFolderAsync();
        }

        private void OnPolishLanguageSelected(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Polish language selected.");
            _fileExplorer.ChangeLanguage("pl-PL");
        }

        private void OnEnglishLanguageSelected(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("English language selected.");
            _fileExplorer.ChangeLanguage("en-US");
        }

        private async void OnLoadDirectoryButtonClick(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Load directory button clicked.");
            await _fileExplorer.LoadDirectoryAsync("C:\\YourDirectory");
        }

        private async void OnSortButtonClick(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Sort button clicked.");
            var sortOptions = new SortOptions
            {
                SortOption = SortOption.Name,
                SortDirection = SortDirection.Ascending
            };
            await _fileExplorer.SortItemsAsync(sortOptions);
        }
    }
}
