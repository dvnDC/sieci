﻿using System;
using System.Collections.Generic;
using System.IO;
using WpfApp1.Enums;
using WpfApp1.Model;
using WpfApp1.ViewModel;

namespace WpfApp1.Helper
{
    public class AlphabeticalComparer : IComparer<FileSystemInfoViewModel>
    {
        public int Compare(FileSystemInfoViewModel x, FileSystemInfoViewModel y)
        {
            return string.Compare(x.Caption, y.Caption, StringComparison.OrdinalIgnoreCase);
        }
    }

    public class ReverseComparer : IComparer<FileSystemInfoViewModel>
    {
        private IComparer<FileSystemInfoViewModel> originalComparer;

        public ReverseComparer(IComparer<FileSystemInfoViewModel> original)
        {
            originalComparer = original;
        }

        public int Compare(FileSystemInfoViewModel x, FileSystemInfoViewModel y)
        {
            return -originalComparer.Compare(x, y);
        }
    }

    public class SizeComparer : IComparer<FileSystemInfoViewModel>
    {
        public int Compare(FileSystemInfoViewModel x, FileSystemInfoViewModel y)
        {
            // Porównaj rozmiary plików lub folderów
            return x.Size.CompareTo(y.Size);
        }
    }

    public class ExtensionComparer : IComparer<FileSystemInfoViewModel>
    {
        public int Compare(FileSystemInfoViewModel x, FileSystemInfoViewModel y)
        {
            // Porównaj rozszerzenia plików
            return string.Compare(x.Extension, y.Extension, StringComparison.OrdinalIgnoreCase);
        }
    }

    public class DateModifiedComparer : IComparer<FileSystemInfoViewModel>
    {
        public int Compare(FileSystemInfoViewModel x, FileSystemInfoViewModel y)
        {
            // Porównaj daty modyfikacji
            return DateTime.Compare(x.LastModified, y.LastModified);
        }
    }

    public class Comperator : IComparer<FileSystemInfoViewModel>
    {
        private readonly SortOptions _sortOptions;

        public Comperator(SortOptions sortOptions)
        {
            _sortOptions = sortOptions;
        }

        public int Compare(FileSystemInfoViewModel x, FileSystemInfoViewModel y)
        {
            int result = 0;
            switch (_sortOptions.SortOption)
            {
                case SortOption.Name:
                    result = string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase);
                    break;
                case SortOption.DateModified:
                    result = DateTime.Compare(x.LastModified, y.LastModified);
                    break;
                case SortOption.Type:
                    result = string.Compare(x.Extension, y.Extension, StringComparison.OrdinalIgnoreCase);
                    break;
            }

            return _sortOptions.SortDirection == SortDirection.Ascending ? result : -result;
        }
    }
}