﻿using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using WpfApp1.Model;

namespace WpfApp1.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<FileMetadata> FileMetadatas { get; set; }
        public DbSet<UserFilePermission> UserFilePermissions { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<FileModificationHistory> FileModificationHistories { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WpfApp1");
                Directory.CreateDirectory(folderPath); // Upewnij się, że katalog istnieje
                string dbPath = Path.Combine(folderPath, "app.db");
                optionsBuilder.UseSqlite($"Data Source={dbPath}");
                Console.WriteLine($"Configured database at: {dbPath}");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasMany(u => u.UserFilePermissions)
                .WithOne(p => p.User)
                .HasForeignKey(p => p.UserId);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Notifications)
                .WithOne(n => n.User)
                .HasForeignKey(n => n.UserId);

            modelBuilder.Entity<FileMetadata>()
                .HasMany(f => f.UserFilePermissions)
                .WithOne(p => p.FileMetadata)
                .HasForeignKey(p => p.FileMetadataId);

            modelBuilder.Entity<FileMetadata>()
                .HasMany(f => f.ModificationHistories)
                .WithOne(m => m.FileMetadata)
                .HasForeignKey(m => m.FileMetadataId);

            modelBuilder.Entity<Notification>()
                .HasOne(n => n.FileMetadata)
                .WithMany()
                .HasForeignKey(n => n.FileMetadataId);

            Console.WriteLine("Model created successfully.");
        }
    }
}
