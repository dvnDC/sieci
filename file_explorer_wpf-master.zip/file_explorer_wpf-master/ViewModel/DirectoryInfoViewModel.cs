﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using WpfApp1.Enums;
using WpfApp1.Helper;
using WpfApp1.Model;
using Application = System.Windows.Application;

namespace WpfApp1.ViewModel
{
    public class DirectoryInfoViewModel : FileSystemInfoViewModel
    {
        public SortOptions SortOptions { get; set; }

        public DispatchedObservableCollection<FileSystemInfoViewModel> Items { get; private set; } = new DispatchedObservableCollection<FileSystemInfoViewModel>();

        private FileSystemWatcher _watcher;

        // Flaga wskazująca, czy folder jest rozwinięty
        public bool IsExpanded { get; set; }
        // Flaga wskazująca, czy element jest wybrany
        public bool IsSelected { get; set; }

        private FileExplorer _fileExplorer;

        public DirectoryInfoViewModel(FileExplorer owner) : base(owner)
        {
            _fileExplorer = owner ?? throw new ArgumentNullException(nameof(owner));
            Items.CollectionChanged += Items_CollectionChanged;
        }

        private void Items_CollectionChanged(object sender, NotifyCollectionChangedEventArgs args)
        {
            switch (args.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    foreach (var item in args.NewItems.Cast<FileSystemInfoViewModel>())
                    {
                        item.PropertyChanged += Item_PropertyChanged;
                    }
                    break;
                case NotifyCollectionChangedAction.Remove:
                    foreach (var item in args.OldItems.Cast<FileSystemInfoViewModel>())
                    {
                        item.PropertyChanged -= Item_PropertyChanged;
                    }
                    break;
            }
        }

        private void Item_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(StatusMessage) && sender is FileSystemInfoViewModel viewModel)
            {
                StatusMessage = viewModel.StatusMessage;
            }
        }

        public bool Open(string path, bool ignoreUnauthorizedAccess = false)
        {
            if (_watcher != null)
            {
                _watcher.Dispose();
            }

            _watcher = new FileSystemWatcher(path)
            {
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName,
                EnableRaisingEvents = true
            };

            _watcher.Changed += (sender, e) => OnFileSystemChanged(e);
            _watcher.Created += (sender, e) => OnFileSystemChanged(e);
            _watcher.Deleted += (sender, e) => OnFileSystemChanged(e);
            _watcher.Renamed += (sender, e) => OnFileSystemRenamed(e);
            _watcher.Error += Watcher_Error;

            Items.Clear();
            var directoryInfo = new DirectoryInfo(path);
            LoadDirectoryAsync(directoryInfo, ignoreUnauthorizedAccess);
            return true;
        }

        private async Task LoadDirectoryAsync(DirectoryInfo directoryInfo, bool ignoreUnauthorizedAccess)
        {
            if (directoryInfo.Exists)
            {
                try
                {
                    var directories = await Task.Run(() =>
                    {
                        try
                        {
                            return directoryInfo.GetDirectories();
                        }
                        catch (UnauthorizedAccessException)
                        {
                            if (!ignoreUnauthorizedAccess)
                            {
                                throw;
                            }
                            return Array.Empty<DirectoryInfo>();
                        }
                    });

                    foreach (var directory in directories)
                    {
                        try
                        {
                            if (directory.Exists)
                            {
                                var directoryVM = new DirectoryInfoViewModel(_fileExplorer) { Model = directory };
                                Application.Current.Dispatcher.Invoke(() => Items.Add(directoryVM));
                                await directoryVM.LoadDirectoryAsync(directory, ignoreUnauthorizedAccess);
                            }
                            StatusMessage = $"Loading directory: {directory.FullName}"; // Ustawienie StatusMessage
                        }
                        catch (UnauthorizedAccessException)
                        {
                            // Ignorujemy zastrzeżone katalogi
                            StatusMessage = $"Access denied to directory: {directory.FullName}";
                        }
                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show($"Wystąpił błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }

                    var files = await Task.Run(() =>
                    {
                        try
                        {
                            return directoryInfo.GetFiles();
                        }
                        catch (UnauthorizedAccessException)
                        {
                            if (!ignoreUnauthorizedAccess)
                            {
                                throw;
                            }
                            return Array.Empty<FileInfo>();
                        }
                    });

                    foreach (var file in files)
                    {
                        try
                        {
                            if (file.Exists)
                            {
                                var fileVM = new FileInfoViewModel(_fileExplorer) { Model = file };
                                Application.Current.Dispatcher.Invoke(() => Items.Add(fileVM));
                            }
                            StatusMessage = $"Loading file: {file.FullName}"; // Ustawienie StatusMessage
                        }
                        catch (UnauthorizedAccessException)
                        {
                            // Ignorujemy zastrzeżone pliki
                            StatusMessage = $"Access denied to file: {file.FullName}";
                        }
                        catch (Exception ex)
                        {
                            System.Windows.MessageBox.Show($"Wystąpił błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }

                    // Ustawienie StatusMessage po załadowaniu katalogu
                    StatusMessage = $"Loaded directory: {directoryInfo.FullName}";
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show($"Wystąpił błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        public async Task SortAsync(SortBy sortBy, Direction direction, bool keepFoldersOnTop)
        {
            try
            {
                if (Model == null)
                {
                    StatusMessage = "Model is not initialized.";
                    return;
                }

                var comparer = GetComparer(sortBy);
                if (direction == Direction.Descending)
                {
                    comparer = new ReverseComparer(comparer);
                }

                // Ustawianie StatusMessage dla bieżącego katalogu
                StatusMessage = $"Sorting directory: {Model.FullName}";

                // Sortowanie elementów w bieżącym katalogu
                var sortedItems = Items.OrderBy(item => item, comparer).ToList();
                if (keepFoldersOnTop)
                {
                    sortedItems = sortedItems.OrderBy(item => !(item is DirectoryInfoViewModel)).ThenBy(item => item, comparer).ToList();
                }

                // Zaktualizuj kolekcję Items, zachowując oryginalne obiekty
                Application.Current.Dispatcher.Invoke(() => UpdateItemsInPlace(sortedItems));

                // Sortowanie podkatalogów równolegle
                var subDirectories = Items.OfType<DirectoryInfoViewModel>().ToList();
                int subFoldersCount = subDirectories.Count;
                Task[] taskArray = new Task[subFoldersCount];

                for (int i = 0; i < taskArray.Length; i++)
                {
                    var directory = subDirectories[i];
                    taskArray[i] = Task.Run(async () =>
                    {
                        // Ustawianie StatusMessage dla podkatalogu
                        StatusMessage = $"Sorting sub-directory: {directory.Model?.FullName ?? "Unknown"}";
                        await directory.SortAsync(sortBy, direction, keepFoldersOnTop);
                    });
                }

                await Task.WhenAll(taskArray);

                // Ustawianie StatusMessage po zakończeniu sortowania
                StatusMessage = $"Sorted directory: {Model.FullName}";
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"An error occurred during sorting: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateItemsInPlace(List<FileSystemInfoViewModel> sortedItems)
        {
            Items.Clear();
            foreach (var item in sortedItems)
            {
                Items.Add(item);
            }
        }

        private void OnFileSystemChanged(FileSystemEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
            try
            {
                // Utworzenie DirectoryInfo na podstawie ścieżki usuniętego pliku/katalogu
                var fullPath = e.FullPath;
                var parentDirPath = Path.GetDirectoryName(fullPath); // Pobranie ścieżki do katalogu nadrzędnego
                    var parentDirInfo = new DirectoryInfo(parentDirPath);

                                        if (parentDirInfo.Exists)
                    {
                        LoadDirectoryAsync(parentDirInfo, ignoreUnauthorizedAccess: true); // Odświeżenie katalogu nadrzędnego
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show($"Wystąpił błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            });
        }

        private void OnFileSystemRenamed(RenamedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                try
                {
                    var directoryInfo = new DirectoryInfo(e.FullPath);
                    if (directoryInfo.Exists)
                    {
                        LoadDirectoryAsync(directoryInfo.Parent, ignoreUnauthorizedAccess: true);
                    }
                    else
                    {
                        // Jeśli katalog nie istnieje, odśwież katalog nadrzędny
                        LoadDirectoryAsync(new DirectoryInfo(e.OldFullPath).Parent, ignoreUnauthorizedAccess: true);
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show($"Wystąpił błąd: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            });
        }

        private IComparer<FileSystemInfoViewModel> GetComparer(SortBy sortBy)
        {
            switch (sortBy)
            {
                case SortBy.ByExtension:
                    return new ExtensionComparer();
                case SortBy.BySize:
                    return new SizeComparer();
                case SortBy.ByDateModified:
                    return new DateModifiedComparer();
                default:
                    return new AlphabeticalComparer();
            }
        }

        private void Watcher_Error(object sender, ErrorEventArgs e)
        {
            // Obsługa błędów monitorowania
            Application.Current.Dispatcher.Invoke(() =>
            {
                // Tutaj możesz wyświetlić komunikat o błędzie lub podjąć inne działania
            });
        }

        public void Sort(SortBy sortBy, Direction direction, bool keepFoldersOnTop)
        {
            var comparer = GetComparer(sortBy);
            if (direction == Direction.Descending)
            {
                comparer = new ReverseComparer(comparer);
            }

            var sortedItems = Items.OrderBy(item => item, comparer).ToList();
            if (keepFoldersOnTop)
            {
                sortedItems = sortedItems.OrderBy(item => !(item is DirectoryInfoViewModel)).ThenBy(item => item, comparer).ToList();
            }

            Items.Clear();
            foreach (var item in sortedItems)
            {
                Items.Add(item);
            }
        }
    }
}