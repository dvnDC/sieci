﻿using System;
using System.Linq;
using System.Security;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WpfApp1.Data;
using WpfApp1.Model;
using WpfApp1.View;
using System.Diagnostics;
using System.Windows;

namespace WpfApp1.Logic
{
    public class FileManager
    {
        private readonly AppDbContext _context;

        public FileManager(AppDbContext context)
        {
            _context = context;
        }

        public async Task InitializeDatabaseAsync()
        {
            try
            {
                var localUserName = Environment.UserName;
                Debug.WriteLine($"Local username: {localUserName}");

                var localUser = await _context.Users.FirstOrDefaultAsync(u => u.Login == localUserName);
                if (localUser == null)
                {
                    Debug.WriteLine("Creating account for local user.");
                    var password = PromptForPassword("Creating account for local user. Enter password:");
                    if (password == null)
                    {
                        Debug.WriteLine("Password prompt cancelled or empty.");
                        throw new ArgumentNullException(nameof(password), "Password cannot be null.");
                    }

                    Debug.WriteLine("Password entered.");
                    localUser = new User
                    {
                        Login = localUserName,
                        Password = ConvertToUnsecureString(password), // Hash and salt the password in a real application
                        IPAddress = "127.0.0.1", // Localhost IP address
                        IsBlocked = false
                    };

                    _context.Users.Add(localUser);
                    await _context.SaveChangesAsync();
                    Debug.WriteLine("Account created and saved.");
                }
                else
                {
                    Debug.WriteLine("User already exists. Prompting for password.");
                    var password = PromptForPassword("Enter password:");
                    if (password == null)
                    {
                        Debug.WriteLine("Password prompt cancelled or empty.");
                        throw new ArgumentNullException(nameof(password), "Password cannot be null.");
                    }

                    Debug.WriteLine("Password entered.");
                    if (localUser.Password != ConvertToUnsecureString(password))
                    {
                        Debug.WriteLine("Incorrect password. Prompting for new password.");
                        var newPassword = PromptForPassword("Incorrect password. Please enter a new password:");
                        if (newPassword == null)
                        {
                            Debug.WriteLine("New password prompt cancelled or empty.");
                            throw new ArgumentNullException(nameof(newPassword), "Password cannot be null.");
                        }

                        Debug.WriteLine("New password entered.");
                        localUser.Password = ConvertToUnsecureString(newPassword); // Hash and salt the password in a real application
                        await _context.SaveChangesAsync();
                        Debug.WriteLine("Password updated.");
                    }
                    else
                    {
                        Debug.WriteLine("Password correct. Welcome back.");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"An error occurred: {ex.Message}");
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public async Task RegisterRemoteUserAsync(string login, string password, string ipAddress)
        {
            var user = new User
            {
                Login = login,
                Password = password, // Hash and salt the password in a real application
                IPAddress = ipAddress,
                IsBlocked = false
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }

        public async Task ManageUsersAsync()
        {
            var users = await _context.Users.ToListAsync();
            Debug.WriteLine("User List:");
            foreach (var user in users)
            {
                Debug.WriteLine($"Login: {user.Login}, IP: {user.IPAddress}, Status: {(user.IsBlocked ? "Blocked" : "Active")}");
            }

            // Implement user management operations such as blocking/unblocking users and adding/removing IP addresses
        }

        private SecureString PromptForPassword(string message)
        {
            Debug.WriteLine("Prompting for password.");
            var dialog = new PasswordDialog { Message = message };
            if (dialog.ShowDialog() == true)
            {
                Debug.WriteLine("Password dialog confirmed.");
                return dialog.Password;
            }
            Debug.WriteLine("Password dialog cancelled.");
            return null;
        }

        private static string ConvertToUnsecureString(SecureString securePassword)
        {
            if (securePassword == null)
                throw new ArgumentNullException(nameof(securePassword));

            var unmanagedString = IntPtr.Zero;
            try
            {
                unmanagedString = System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(securePassword);
                return System.Runtime.InteropServices.Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }
    }
}
