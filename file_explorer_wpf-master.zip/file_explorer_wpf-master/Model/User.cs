﻿using System.Collections.Generic;

namespace WpfApp1.Model
{
    public class User
    {
        public int UserId { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string IPAddress { get; set; }
        public bool IsBlocked { get; set; } // Dodaj tę linię

        public ICollection<UserFilePermission> UserFilePermissions { get; set; }
        public ICollection<Notification> Notifications { get; set; }
    }
}
