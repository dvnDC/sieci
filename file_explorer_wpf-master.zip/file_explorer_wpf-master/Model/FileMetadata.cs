﻿using System;
using System.Collections.Generic;

namespace WpfApp1.Model
{
    public class FileMetadata
    {
        public int FileMetadataId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public string Description { get; set; }
        public string FilePath { get; set; }

        public ICollection<UserFilePermission> UserFilePermissions { get; set; }
        public ICollection<FileModificationHistory> ModificationHistories { get; set; }
    }

    public class FileModificationHistory
    {
        public int FileModificationHistoryId { get; set; }
        public int FileMetadataId { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedAt { get; set; }
        public string ChangeDescription { get; set; }

        public FileMetadata FileMetadata { get; set; }
    }
}
