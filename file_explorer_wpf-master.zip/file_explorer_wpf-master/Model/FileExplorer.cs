﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Forms;
using WpfApp1.Dictionary.Language;
using WpfApp1.Enums;
using WpfApp1.Helper;
using WpfApp1.View;
using WpfApp1.ViewModel;
using System.Collections.ObjectModel;
using Application = System.Windows.Application;

namespace WpfApp1.Model
{
    public class FileExplorer : ViewModelBase
    {
        private string _statusMessage;
        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                NotifyPropertyChanged(nameof(StatusMessage));
            }
        }
        public ObservableCollection<FileSystemInfoViewModel> Items { get; set; } = new DispatchedObservableCollection<FileSystemInfoViewModel>();

        public async Task LoadDirectoryAsync(string path)
        {
            // Asynchronous directory loading logic
            await Task.Run(() =>
            {
                var directoryInfo = new DirectoryInfo(path);
                var items = directoryInfo.GetFileSystemInfos()
                                         .Select(info => new FileSystemInfoViewModel(info))
                                         .ToList();

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Items.Clear();
                    foreach (var item in items)
                    {
                        Items.Add(item);
                    }
                });
            });
        }

        public async Task SortItemsAsync(SortOptions sortOptions)
        {
            var comparer = new Comperator(sortOptions);
            var sortedItems = await Task.Run(() =>
            {
                return Items.OrderBy(item => item, comparer).ToList();
            });

            Application.Current.Dispatcher.Invoke(() =>
            {
                Items.Clear();
                foreach (var item in sortedItems)
                {
                    Items.Add(item);
                }
            });
        }

        public async Task OpenRootFolderAsync()
        {
            var dlg = new System.Windows.Forms.FolderBrowserDialog() { Description = "Select directory to open" };
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var path = dlg.SelectedPath;
                await Task.Run(() =>
                {
                    try
                    {
                        OpenRoot(path, ignoreUnauthorizedAccess: true); // Przekazujemy oba argumenty
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        // Obsługa błędu dostępu do katalogu
                        System.Windows.Application.Current.Dispatcher.Invoke(() =>
                        {
                            System.Windows.MessageBox.Show($"Access to the path '{path}' is denied.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        });
                    }
                    catch (IOException ex)
                    {
                        // Obsługa innych błędów wejścia/wyjścia
                        System.Windows.Application.Current.Dispatcher.Invoke(() =>
                        {
                            System.Windows.MessageBox.Show($"An I/O error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        });
                    }
                });
            }
        }

        public void OpenRoot(string path, bool ignoreUnauthorizedAccess = false)
        {
            Root = new DirectoryInfoViewModel(this);
            bool isOpened = Root.Open(path, ignoreUnauthorizedAccess);

            if (isOpened)
            {
                NotifyPropertyChanged(nameof(Root)); // Poinformuj, że Root się zmienił
                Root.PropertyChanged += Root_PropertyChanged;
                StatusMessage = "Ready"; // Ustawienie StatusMessage na "Ready"
            }
        }

        public DirectoryInfoViewModel Root { get; private set; }
        public ICommand OpenCommand { get; }
        public ICommand ExitCommand { get; }
        public ICommand SortRootFolderCommand { get; }
        public ICommand OpenFileCommand { get; }
        public ICommand ShowSortDialogCommand { get; }

        public static readonly string[] TextFilesExtensions = { ".txt", ".ini", ".log" };

        private void ShowSortDialog(object parameter)
        {
            try
            {
                var dialog = new SortDialog(this); // Przekazuj 'this' jako FileExplorer ViewModel
                if (dialog.ShowDialog() == true)
                {
                    // Można dodać dodatkowe działania po zamknięciu dialogu, jeśli jest to potrzebne
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"An error occurred while opening the sort dialog: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanExecuteOpenFile(object parameter)
        {
            return true;
        }

        private string _selectedItemContent;
        public string SelectedItemContent
        {
            get => _selectedItemContent;
            set
            {
                _selectedItemContent = value;
                NotifyPropertyChanged(nameof(SelectedItemContent));
            }
        }
        private void Root_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(DirectoryInfoViewModel.StatusMessage))
            {
                StatusMessage = (sender as DirectoryInfoViewModel)?.StatusMessage;
            }
        }

        private string _selectedLanguage;
        public string SelectedLanguage
        {
            get => _selectedLanguage;
            set
            {
                _selectedLanguage = value;
                NotifyPropertyChanged(nameof(SelectedLanguage));
                NotifyPropertyChanged(nameof(IsPolishSelected));
                NotifyPropertyChanged(nameof(IsEnglishSelected));
            }
        }

        public bool IsPolishSelected => SelectedLanguage == "pl-PL";
        public bool IsEnglishSelected => SelectedLanguage == "en-US";

        public FileExplorer()
        {
            OpenCommand = new RelayCommand(Open);
            ExitCommand = new RelayCommand(Exit);
            SortRootFolderCommand = new AsyncRelayCommand(SortRootFolderExecuteAsync, CanSortRootFolderExecute);
            OpenFileCommand = new RelayCommand(OpenFileExecute, OpenFileCanExecute);
            ShowSortDialogCommand = new RelayCommand(ShowSortDialog);

            SelectedLanguage = "en-US";
        }

        private bool OpenFileCanExecute(object parameter)
        {
            if (parameter is FileInfoViewModel viewModel)
            {
                var extension = viewModel.Extension?.ToLower();
                return TextFilesExtensions.Contains(extension);
            }
            return false;
        }

        private void OpenFileExecute(object parameter)
        {
            if (parameter is FileInfoViewModel viewModel)
            {
                OpenFile(viewModel.Model.FullName);
            }
        }

        private SortOptions _sortOptions = new SortOptions();

        public SortOptions SortOptions
        {
            get => _sortOptions;
            set
            {
                _sortOptions = value;
                NotifyPropertyChanged(nameof(SortOptions));
            }
        }

        private void Open(object parameter)
        {
            var description = Strings.SelectDirectoryDescription;

            var dialog = new System.Windows.Forms.FolderBrowserDialog() { Description = description };
            var result = dialog.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                string path = dialog.SelectedPath;
                OpenRoot(path);
            }
        }

        public void OpenFile(string filePath)
        {
            try
            {
                // Odczytanie zawartości pliku
                string fileContent = File.ReadAllText(filePath);

                // Przypisanie zawartości pliku do właściwości w ViewModel, która jest powiązana z widokiem
                SelectedItemContent = fileContent;
            }
            catch (Exception ex)
            {
                // Obsługa wyjątków, np. gdy plik nie istnieje, nie ma uprawnień itp.
                System.Windows.MessageBox.Show($"Error reading file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Exit(object parameter)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private bool CanSortRootFolderExecute(object parameter)
        {
            return Root != null && Root.Items.Any();
        }

        private async Task SortRootFolderExecuteAsync(object parameter)
        {
            if (Root != null)
            {
                try
                {
                    await Root.SortAsync(SortOptions.SortBy, SortOptions.Direction, SortOptions.KeepFoldersOnTop);
                    StatusMessage = "Ready";
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show($"An error occurred during sorting: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Root is not initialized.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void ChangeCulture(string cultureName)
        {
            CultureInfo.CurrentCulture = new CultureInfo(cultureName);
            CultureInfo.CurrentUICulture = new CultureInfo(cultureName);

            NotifyPropertyChanged("Lang");
        }

        // Lang, zwraca aktualny jezyk
        public string Lang => CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;

        public void ChangeLanguage(string language)
        {
            CultureResources.ChangeCulture(new CultureInfo(language));
            SelectedLanguage = language;
        }

        public void SortDirectory(SortBy sortType, Direction sortOrder, bool keepFoldersOnTop)
        {
            if (Root != null)
            {
                try
                {
                    Root.Sort(sortType, sortOrder, keepFoldersOnTop);
                    NotifyPropertyChanged(nameof(Root)); // Odświeżenie widoku
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show($"An error occurred during sorting: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Root is not initialized.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
