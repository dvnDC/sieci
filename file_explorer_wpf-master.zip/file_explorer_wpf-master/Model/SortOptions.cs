﻿using System.ComponentModel;
using WpfApp1.Enums;

namespace WpfApp1.Model
{
    public class SortOptions : INotifyPropertyChanged
    {
        private SortBy _sortBy;
        private Direction _direction;
        private bool _keepFoldersOnTop;
        public SortOption SortOption { get; set; }
        public SortDirection SortDirection { get; set; }

        public SortBy SortBy
        {
            get => _sortBy;
            set
            {
                _sortBy = value;
                OnPropertyChanged(nameof(SortBy));
            }
        }

        public Direction Direction
        {
            get => _direction;
            set
            {
                _direction = value;
                OnPropertyChanged(nameof(Direction));
            }
        }

        public bool KeepFoldersOnTop
        {
            get => _keepFoldersOnTop;
            set
            {
                _keepFoldersOnTop = value;
                OnPropertyChanged(nameof(KeepFoldersOnTop));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
