﻿using System;
using WpfApp1.Model;

namespace WpfApp1.Model
{
    public class Notification
    {
        public int NotificationId { get; set; }
        public int UserId { get; set; }
        public int FileMetadataId { get; set; }
        public string Message { get; set; }
        public DateTime CreatedAt { get; set; }

        public User User { get; set; }
        public FileMetadata FileMetadata { get; set; }
    }
}
