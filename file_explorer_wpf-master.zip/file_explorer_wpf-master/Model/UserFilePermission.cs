﻿using WpfApp1.Model;

namespace WpfApp1.Model
{
    public class UserFilePermission
    {
        public int UserFilePermissionId { get; set; }
        public int UserId { get; set; }
        public int FileMetadataId { get; set; }
        public string PermissionType { get; set; }

        public User User { get; set; }
        public FileMetadata FileMetadata { get; set; }
    }
}
