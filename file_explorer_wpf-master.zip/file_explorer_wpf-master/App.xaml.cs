﻿using System;
using System.IO;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using WpfApp1.Data;
using WpfApp1.Logic;
using WpfApp1.View;

namespace WpfApp1
{
    public partial class App : Application
    {
        private readonly IServiceProvider _serviceProvider;

        public App()
        {
            var services = new ServiceCollection();
            ConfigureServices(services);
            _serviceProvider = services.BuildServiceProvider();
        }

        private void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<AppDbContext>(options =>
                options.UseSqlite($"Data Source={Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WpfApp1", "app.db")}"));

            services.AddTransient<FileManager>();

            // Rejestracja innych usług, np. ViewModeli
        }

        protected override async void OnStartup(StartupEventArgs e)
        {
            try
            {
                string logFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WpfApp1", "app.log");
                using (var writer = new StreamWriter(logFilePath, append: true))
                {
                    Console.SetOut(writer);

                    string folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WpfApp1");
                    Console.WriteLine($"Checking if directory exists at: {folderPath}");

                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath); // Upewnij się, że katalog istnieje
                        Console.WriteLine($"Directory created at: {folderPath}");
                    }
                    else
                    {
                        Console.WriteLine($"Directory already exists at: {folderPath}");
                    }

                    var dbPath = Path.Combine(folderPath, "app.db");
                    Console.WriteLine($"Database path: {dbPath}");

                    var context = _serviceProvider.GetRequiredService<AppDbContext>();
                    await context.Database.MigrateAsync();
                    Console.WriteLine("Database migrated successfully.");

                    var fileManager = _serviceProvider.GetRequiredService<FileManager>();
                    await fileManager.InitializeDatabaseAsync();
                    Console.WriteLine("FileManager initialized successfully.");

                    // Uruchomienie głównego okna aplikacji
                    var mainWindow = new MainWindow();
                    Console.WriteLine("Opening MainWindow.");
                    mainWindow.Show();

                    base.OnStartup(e);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
