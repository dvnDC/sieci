﻿using System;
using System.Windows.Input;
using Microsoft.Win32;
using System.Windows;
using WpfApp1.ViewModel;
using WpfApp1.Helper;
using System.Globalization;

namespace WpfApp1.Model
{
    public class FileExplorer : ViewModelBase
    {
        private DirectoryInfoViewModel _root;

        public DirectoryInfoViewModel Root
        {
            get => _root;
            set
            {
                _root = value;
                NotifyPropertyChanged(nameof(Root));
            }
        }

        // Dodajemy dwie nowe właściwości ICommand
        public ICommand OpenCommand { get; }
        public ICommand ExitCommand { get; }

        public FileExplorer()
        {
            // Inicjalizacja komend z ich odpowiednimi akcjami
            OpenCommand = new RelayCommand(Open);
            ExitCommand = new RelayCommand(Exit);
        }

        private void Open(object parameter)
        {
            // Tu dodajemy logikę otwierania folderu
            var dialog = new System.Windows.Forms.FolderBrowserDialog();
            var result = dialog.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                string path = dialog.SelectedPath;
                OpenRoot(path);
            }
        }

        private void Exit(object parameter)
        {
            // Logika zamknięcia aplikacji
            Application.Current.Shutdown();
        }

        public void OpenRoot(string path)
        {
            Root = new DirectoryInfoViewModel();
            bool isOpened = Root.Open(path);

            if (!isOpened)
            {
                // Tu możesz obsłużyć błąd otwierania folderu
            }
        }

        public void ChangeCulture(string cultureName)
        {
            CultureInfo.CurrentCulture = new CultureInfo(cultureName);
            CultureInfo.CurrentUICulture = new CultureInfo(cultureName);

            // Tu wywołujesz NotifyPropertyChanged dla wszystkich właściwości, które mogą zależeć od kultury
            NotifyPropertyChanged("Lang");
            // Możesz dodać więcej NotifyPropertyChanged jeśli jest taka potrzeba
        }

        // Właściwość Lang, która zwraca aktualną kulturę
        public string Lang => CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;


        public void ChangeLanguage(string language)
        {
            CultureResources.ChangeCulture(new CultureInfo(language));
            NotifyPropertyChanged("Lang"); // Aby powiadomić o zmianie języka
        }
    }
}
