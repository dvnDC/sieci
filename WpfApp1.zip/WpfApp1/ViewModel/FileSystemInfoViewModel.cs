﻿using System;
using System.IO;
using WpfApp1.Model;
using WpfApp1.ViewModel;


namespace WpfApp1.ViewModel
{
    public class FileSystemInfoViewModel : ViewModelBase
    {
        private FileSystemInfo _fileSystemInfo;
        private string _caption;

        public FileSystemInfo Model
        {
            get => _fileSystemInfo;
            set
            {
                if (_fileSystemInfo != value)
                {
                    _fileSystemInfo = value;
                    Caption = GenerateCaption(value); // Przypisujemy tekst do wyświetlenia na podstawie obiektu FileSystemInfo
                    NotifyPropertyChanged(nameof(Model));
                }
            }
        }

        // Właściwość Caption, która będzie wyświetlana w widoku
        public string Caption
        {
            get => _caption;
            set
            {
                if (_caption != value)
                {
                    _caption = value;
                    NotifyPropertyChanged(nameof(Caption));
                }
            }
        }

        // Metoda generująca tekst do wyświetlenia na podstawie obiektu FileSystemInfo
        private string GenerateCaption(FileSystemInfo fileInfo)
        {
            // Tutaj możesz dostosować, jak ma być generowany tekst, np. tylko nazwa pliku/katalogu
            return fileInfo.Name;
        }
    }

}