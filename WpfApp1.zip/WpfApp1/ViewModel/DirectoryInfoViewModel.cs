﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;

namespace WpfApp1.ViewModel
{
    public class DirectoryInfoViewModel : FileSystemInfoViewModel
    {
        public ObservableCollection<FileSystemInfoViewModel> Items { get; private set; }
            = new ObservableCollection<FileSystemInfoViewModel>();

        private FileSystemWatcher _watcher;

        public DirectoryInfoViewModel()
        {
            // Konstruktor
        }

        public bool Open(string path)
        {
            if (_watcher != null)
            {
                _watcher.Dispose();
            }

            _watcher = new FileSystemWatcher(path)
            {
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName,
                EnableRaisingEvents = true
            };

            _watcher.Changed += (sender, e) => OnFileSystemChanged(e);
            _watcher.Created += (sender, e) => OnFileSystemChanged(e);
            _watcher.Deleted += (sender, e) => OnFileSystemChanged(e);
            _watcher.Renamed += (sender, e) => OnFileSystemRenamed(e);
            _watcher.Error += Watcher_Error;

            Items.Clear();
            var directoryInfo = new DirectoryInfo(path);
            LoadDirectory(directoryInfo);
            return true;
        }

        private void LoadDirectory(DirectoryInfo directoryInfo)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                // Wyczyść obecną zawartość Items
                Items.Clear();

                // Ładowanie podkatalogów
                foreach (var directory in directoryInfo.GetDirectories())
                {
                    try
                    {
                        var directoryVM = new DirectoryInfoViewModel { Model = new DirectoryInfo(directory.FullName) };
                        Items.Add(directoryVM);
                        // Opcjonalnie: Rekurencyjne ładowanie podkatalogów może zostać tutaj dodane lub pominięte w zależności od potrzeb
                        directoryVM.LoadDirectory(directory);
                    }
                    catch (Exception ex)
                    {
                        // Opcjonalnie: Obsługa wyjątków, np. brak dostępu
                    }
                }

                // Ładowanie plików
                foreach (var file in directoryInfo.GetFiles())
                {
                    try
                    {
                        Items.Add(new FileInfoViewModel { Model = new FileInfo(file.FullName) });
                    }
                    catch (Exception ex)
                    {
                        // Opcjonalnie: Obsługa wyjątków, np. brak dostępu
                    }
                }
            });
        }


        private void OnFileSystemChanged(FileSystemEventArgs e)
        {
            // Obsługa zmian w systemie plików
            Application.Current.Dispatcher.Invoke(() =>
            {
                // Tutaj odświeżasz Items lub wykonujesz inne akcje związane z aktualizacją UI
            });
        }

        private void OnFileSystemRenamed(RenamedEventArgs e)
        {
            // Obsługa zmiany nazwy pliku/katalogu
            Application.Current.Dispatcher.Invoke(() =>
            {
                // Tutaj odświeżasz Items lub wykonujesz inne akcje związane z aktualizacją UI
            });
        }

        private void Watcher_Error(object sender, ErrorEventArgs e)
        {
            // Obsługa błędów monitorowania
            Application.Current.Dispatcher.Invoke(() =>
            {
                // Tutaj możesz wyświetlić komunikat o błędzie lub podjąć inne działania
            });
        }
    }
}
