﻿using System;
using System.Windows.Media;
using System.IO;
using System.Windows.Media.Imaging;

namespace WpfApp1.ViewModel
{
    public class FileInfoViewModel : FileSystemInfoViewModel
    {
        private ImageSource _icon;

        public ImageSource Icon
        {
            get => _icon;
            set
            {
                _icon = value;
                NotifyPropertyChanged(nameof(Icon));
            }
        }

        public new FileInfo Model
        {
            get => (FileInfo)base.Model;
            set
            {
                base.Model = value;
                if (value != null)
                {
                    LoadIcon(value);
                }
            }
        }

        private void LoadIcon(FileInfo fileInfo)
        {
            // Przykładowa logika wyboru ikony na podstawie rozszerzenia pliku
            var extension = fileInfo.Extension.ToLower();
            switch (extension)
            {
                case ".txt":
                    Icon = new BitmapImage(new Uri("pack://application:,,,/Asset/Icon/FileTxt.png"));
                    break;
                case ".png":
                    Icon = new BitmapImage(new Uri("pack://application:,,,/Asset/Icon/FilePhoto.png"));
                    break;
                case ".jpg":
                    Icon = new BitmapImage(new Uri("pack://application:,,,/Asset/Icon/FilePhoto.png"));
                    break;
                default:
                    Icon = new BitmapImage(new Uri("pack://application:,,,/Asset/Icon/File.png"));
                    break;
            }
        }
    }
}
