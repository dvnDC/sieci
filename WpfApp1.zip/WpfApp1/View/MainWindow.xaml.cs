﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using WpfApp1.Model;

using IOPath = System.IO.Path;
using System.Globalization;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private FileExplorer _fileExplorer;

        public MainWindow()
        {
            InitializeComponent();
            var fileExplorerViewModel = new FileExplorer(); // Tworzenie instancji ViewModel
            DataContext = fileExplorerViewModel; // Przypisanie ViewModel do DataContext okna
            _fileExplorer = new FileExplorer(); // Inicjalizacja _fileExplorer i przypisanie go do DataContext
            DataContext = _fileExplorer;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var fileExplorer = new FileExplorer();
            // Tutaj możesz dodać logikę otwierania domyślnego katalogu lub pokazywania dialogu wyboru folderu

            var dlg = new FolderBrowserDialog() { Description = "Select directory to open" };
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var path = dlg.SelectedPath;
                fileExplorer.OpenRoot(path);
            }

            DataContext = fileExplorer;
        }

        private void Window_Loaded2(object sender, RoutedEventArgs e)
        {
            var dlg = new FolderBrowserDialog() { Description = "Select directory to open" };
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var path = dlg.SelectedPath;
                var fileExplorer = new FileExplorer();
                fileExplorer.OpenRoot(path);
                DataContext = fileExplorer;
            }
        }
        private void OnPolishLanguageSelected(object sender, MouseButtonEventArgs e)
        {
            _fileExplorer.ChangeLanguage("pl-PL");
            //ChangeCulture(new CultureInfo("pl-PL"));
        }

        private void OnEnglishLanguageSelected(object sender, MouseButtonEventArgs e)
        {
            _fileExplorer.ChangeLanguage("en-US");
            //ChangeCulture(new CultureInfo("en-US"));
        }

        private void ChangeCulture(CultureInfo culture)
        {
            _fileExplorer.ChangeCulture(culture.Name);
            // Refresh UI elements that depend on resources
            RefreshResources();
        }

        private void RefreshResources()
        {
            // Implement logic to refresh UI elements that depend on localized resources
        }


        //private void OpenFolder_Click(object sender, RoutedEventArgs e)
        //{
        //    using (var dlg = new FolderBrowserDialog())
        //    {
        //        dlg.Description = "Select a folder";
        //        if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        //        {
        //            string selectedPath = dlg.SelectedPath;
        //            LoadDirectoryStructure(selectedPath);
        //        }
        //    }
        //}

        //private void OpenFile_Click(object sender, RoutedEventArgs e)
        //{
        //    // Tag TreeViewItem needs path to file!!
        //    if (DiskTreeView.SelectedItem is TreeViewItem selectedItem && selectedItem.Tag is string filePath)
        //    {
        //        // open file and progress with fn logic
        //        DisplayFileContent(filePath);
        //        UpdateStatusBar(filePath);
        //    }
        //}


        //private void LoadDirectoryStructure(string path)
        //{
        //    var rootItem = new TreeViewItem
        //    {
        //        Header = IOPath.GetFileName(path),
        //        Tag = path
        //    };

        //    FillTreeViewItemWithFileSystemEntries(rootItem, path);
        //    DiskTreeView.Items.Clear();
        //    DiskTreeView.Items.Add(rootItem);
        //    rootItem.ExpandSubtree(); // expend all elements
        //}

        //private void FillTreeViewItemWithFileSystemEntries(TreeViewItem item, string path)
        //{
        //    foreach (var directoryPath in Directory.GetDirectories(path))
        //    {
        //        var directoryItem = new TreeViewItem
        //        {
        //            Header = IOPath.GetFileName(directoryPath),
        //            Tag = directoryPath
        //        };

        //        AssignContextMenu(directoryItem, isDirectory: true);
        //        FillTreeViewItemWithFileSystemEntries(directoryItem, directoryPath);
        //        item.Items.Add(directoryItem);
        //    }

        //    foreach (var filePath in Directory.GetFiles(path))
        //    {
        //        var fileItem = new TreeViewItem
        //        {
        //            Header = IOPath.GetFileName(filePath),
        //            Tag = filePath
        //        };

        //        AssignContextMenu(fileItem, isDirectory: false);
        //        item.Items.Add(fileItem);
        //    }
        //}

        //private void AssignContextMenu(TreeViewItem item, bool isDirectory)
        //{
        //    var contextMenu = new ContextMenu();

        //    // Open MenuItem (only for files)
        //    if (!isDirectory)
        //    {
        //        var openMenuItem = new MenuItem { Header = "Open" };
        //        openMenuItem.Click += OpenFile_Click; 
        //        contextMenu.Items.Add(openMenuItem);
        //    }

        //    // Delete MenuItem (for both files and directories)
        //    var deleteMenuItem = new MenuItem { Header = "Delete" };
        //    deleteMenuItem.Click += DeleteMenuItem_Click; 
        //    contextMenu.Items.Add(deleteMenuItem);

        //    // Create MenuItem (only for directories)
        //    if (isDirectory)
        //    {
        //        var createMenuItem = new MenuItem { Header = "Create" };
        //        createMenuItem.Click += CreateMenuItem_Click; 
        //        contextMenu.Items.Add(createMenuItem);
        //    }

        //    item.ContextMenu = contextMenu;
        //}




        //private void DisplayFileContent(string filePath)
        //{
        //    using (var textReader = System.IO.File.OpenText(filePath))
        //    {
        //        string text = textReader.ReadToEnd();
        //        FileContentTextBlock.Text = text;
        //    }
        //}


        //private void Exit_Click(object sender, RoutedEventArgs e)
        //{
        //    this.Close();
        //}

        //private void DeleteMenuItem_Click(object sender, RoutedEventArgs e)
        //{
        //    if (DiskTreeView.SelectedItem is TreeViewItem selectedItem)
        //    {
        //        string path = selectedItem.Tag.ToString();
        //        if (File.Exists(path))
        //        {
        //            File.Delete(path);
        //        }
        //        else if (Directory.Exists(path))
        //        {
        //            Directory.Delete(path, recursive: true);
        //        }
        //        var parent = selectedItem.Parent as TreeViewItem;
        //        parent.Items.Remove(selectedItem);
        //    }
        //}

        //private void CreateMenuItem_Click(object sender, RoutedEventArgs e)
        //{
        //    if (DiskTreeView.SelectedItem is TreeViewItem selectedItem)
        //    {
        //        var createDialog = new CreateDialog();
        //        if (createDialog.ShowDialog() == true)
        //        {
        //            try
        //            {
        //                string parentPath = selectedItem.Tag.ToString();
        //                string newPath = System.IO.Path.Combine(parentPath, createDialog.CreatedName);

        //                if (createDialog.IsFile)
        //                {
        //                    File.Create(newPath).Dispose(); // Dispose() to close streaming
        //                }
        //                else
        //                {
        //                    Directory.CreateDirectory(newPath);
        //                }

        //                // set attributes for new item
        //                File.SetAttributes(newPath, createDialog.CreatedAttributes);

        //                // refresh tree view
        //                var newItem = new TreeViewItem
        //                {
        //                    Header = createDialog.CreatedName,
        //                    Tag = newPath
        //                };
        //                selectedItem.Items.Add(newItem);
        //                selectedItem.IsExpanded = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                System.Windows.MessageBox.Show($"Error creating file or directory: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        //            }
        //        }
        //    }
        //}
        //private void UpdateStatusBar(string path)
        //{
        //    var attributes = File.GetAttributes(path);
        //    var attributesString = ConvertAttributesToString(attributes);
        //    StatusBarTextBlock.Text = $"Attributes: {attributesString}";
        //}

        //private string ConvertAttributesToString(FileAttributes attributes)
        //{
        //    var result = new StringBuilder("rash");
        //    result[0] = attributes.HasFlag(FileAttributes.ReadOnly) ? 'r' : '-';
        //    result[1] = attributes.HasFlag(FileAttributes.Archive) ? 'a' : '-';
        //    result[2] = attributes.HasFlag(FileAttributes.System) ? 's' : '-';
        //    result[3] = attributes.HasFlag(FileAttributes.Hidden) ? 'h' : '-';
        //    return result.ToString();
        //}

        //private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        //{
        //    if (e.NewValue is TreeViewItem selectedItem && selectedItem.Tag is string path)
        //    {
        //        UpdateStatusBar(path);
        //    }
        //}
    }
}