﻿using System;
using System.Windows.Input;
using System.IO;
using Microsoft.Win32;
using System.Windows;
using WpfApp1.ViewModel;
using WpfApp1.Helper;
using WpfApp1.View;
using WpfApp1.Dictionary.Language;
using System.Globalization;
using System.Linq;
using WpfApp1.Enums;

namespace WpfApp1.Model
{
    public class FileExplorer : ViewModelBase
    {
        private DirectoryInfoViewModel _root;

        public DirectoryInfoViewModel Root
        {
            get => _root;
            set
            {
                _root = value;
                NotifyPropertyChanged(nameof(Root));
            }
        }

        // interface ICommand
        public ICommand OpenCommand { get; }
        public ICommand ExitCommand { get; }
        public ICommand SortRootFolderCommand { get; private set; }
        public ICommand OpenFileCommand { get; }


        private bool CanExecuteOpenFile(object parameter)
        {
            return true;  // Tutaj można dodać bardziej szczegółowe warunki, jeśli potrzebne
        }

        private string _selectedItemContent;
        public string SelectedItemContent
        {
            get => _selectedItemContent;
            set
            {
                _selectedItemContent = value;
                NotifyPropertyChanged(nameof(SelectedItemContent));
            }
        }

        private string _selectedLanguage;
        public string SelectedLanguage
        {
            get => _selectedLanguage;
            set
            {
                _selectedLanguage = value;
                NotifyPropertyChanged(nameof(SelectedLanguage));
                // Aktualizuj wizualne zaznaczenie flagi
                NotifyPropertyChanged(nameof(IsPolishSelected));
                NotifyPropertyChanged(nameof(IsEnglishSelected));
            }
        }

        public bool IsPolishSelected => SelectedLanguage == "pl-PL";
        public bool IsEnglishSelected => SelectedLanguage == "en-US";

        public static readonly string[] TextFilesExtensions = { ".txt", ".ini", ".log" };

        public FileExplorer()
        {
            OpenCommand = new RelayCommand(Open);
            ExitCommand = new RelayCommand(Exit);
            SortRootFolderCommand = new RelayCommand(o => ShowSortDialog(), o => Root != null && Root.Items.Any());
            OpenFileCommand = new RelayCommand(OpenFileExecute, OpenFileCanExecute);

            SelectedLanguage = "en-US";
        }
        private bool OpenFileCanExecute(object parameter)
        {
            if (parameter is FileInfoViewModel viewModel)
            {
                var extension = viewModel.Extension?.ToLower();
                return TextFilesExtensions.Contains(extension);
            }
            return false;
        }

        private void OpenFileExecute(object parameter)
        {
            if (parameter is FileInfoViewModel viewModel)
            {
                // Logika otwierania pliku
                try
                {
                    string content = File.ReadAllText(viewModel.Model.FullName);
                    // Aktualizuj UI lub wykonaj inne operacje
                    Application.Current.Dispatcher.Invoke(() => {
                        SelectedItemContent = content; // Asumując, że jest to property powiązane z UI
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error reading file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private SortOptions _sortOptions = new SortOptions();

        public SortOptions SortOptions
        {
            get => _sortOptions;
            set
            {
                _sortOptions = value;
                NotifyPropertyChanged(nameof(SortOptions));
            }
        }


        private void Open(object parameter)
        {
            var description = Strings.SelectDirectoryDescription;

            var dialog = new System.Windows.Forms.FolderBrowserDialog() { Description = description };
            var result = dialog.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                string path = dialog.SelectedPath;
                OpenRoot(path);
            }
        }
        public void OpenFile(string filePath)
        {
            try
            {
                // Odczytanie zawartości pliku
                string fileContent = File.ReadAllText(filePath);

                // Przypisanie zawartości pliku do właściwości w ViewModel, która jest powiązana z widokiem
                SelectedItemContent = fileContent;
            }
            catch (Exception ex)
            {
                // Obsługa wyjątków, np. gdy plik nie istnieje, nie ma uprawnień itp.
                MessageBox.Show($"Error reading file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void Exit(object parameter)
        {
            Application.Current.Shutdown();
        }

        public void OpenRoot(string path)
        {
            Root = new DirectoryInfoViewModel(this);
            bool isOpened = Root.Open(path);

            if (isOpened)
            {
                NotifyPropertyChanged(nameof(Root)); // Poinformuj, że Root się zmienił
            }
        }

        private bool CanSortRootFolderExecute(object parameter)
        {
            // Komenda może być wykonana tylko jeśli drzewo katalogów jest załadowane
            return Root != null && Root.Items.Any();
        }

        private void SortRootFolderExecute(object parameter)
        {
            if (Root != null)
            {
                // Przykładowo, sortuj alfabetycznie i rosnąco z folderami na górze
                Root.Sort(SortBy.Alphabetically, Direction.Ascending, true);
                NotifyPropertyChanged(nameof(Root)); // Odświeżenie widoku
            }
        }


        public void ChangeCulture(string cultureName)
        {
            CultureInfo.CurrentCulture = new CultureInfo(cultureName);
            CultureInfo.CurrentUICulture = new CultureInfo(cultureName);

            NotifyPropertyChanged("Lang");
        }

        // Lang, zwraca aktualny jezyk
        public string Lang => CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;


        public void ChangeLanguage(string language)
        {
            CultureResources.ChangeCulture(new CultureInfo(language));
            SelectedLanguage = language;
        }

        private void ShowSortDialog()
        {
            var dialog = new SortDialog(this); // Przekazuj 'this' jako FileExplorer ViewModel
            if (dialog.ShowDialog() == true)
            {
                // Można dodać dodatkowe działania po zamknięciu dialogu, jeśli jest to potrzebne
            }
        }

        public void SortDirectory(SortBy sortType, Direction sortOrder, bool keepFoldersOnTop)
        {
            if (Root != null)
            {
                Root.Sort(sortType, sortOrder, keepFoldersOnTop);
                NotifyPropertyChanged(nameof(Root)); // Odświeżenie widoku
            }
        }


    }
}
